//
//  food.swift
//  TableView App
//
//  Created by Emily Denham on 2/25/24.
//

import Foundation
import UIKit

struct Food {
    let name: String
}

class TableViewController: UITableViewController {

    let foods = [
        Food(name: "Pizza"),
        Food(name: "Burger"),
        Food(name: "Sushi"),
        Food(name: "Pasta"),
        Food(name: "Salad"),
        Food(name: "Steak"),
        Food(name: "Tacos"),
        Food(name: "Ramen"),
        Food(name: "Curry"),
        Food(name: "Paella")
    ]

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return foods.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = foods[indexPath.row].name
        return cell
    }
}

