//
//  FoodDetailViewController.swift
//  TableView App
//
//  Created by Emily Denham on 2/25/24.
//
import UIKit

class FoodDetailViewController: UIViewController {
   
    var foodName: String?
    
    
    @IBOutlet weak var foodNameLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    
        foodNameLabel.text = foodName
    }
    

}


