//
//  FoodTableViewController.swift
//  TableView App
//
//  Created by Emily Denham on 2/25/24.
//

import UIKit

class FoodTableViewController: UITableViewController {

    // An array of food names for data source for the table view
    let foods = ["Pizza", "Ramen", "Tacos", "Steak", "Pasta", "Butter Chicken", "Pad Thai", "Chicken Tenders", "Salad", "Gyro"]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "FoodCell")
    }

    

    override func numberOfSections(in tableView: UITableView) -> Int {
       
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // The number of rows is equal to the number of foods in array
        return foods.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Dequeue a reusable cell from the table view using an identifier
        let cell = tableView.dequeueReusableCell(withIdentifier: "FoodCell", for: indexPath)

        // Set the text label of the cell to the name of the food at the current index
        cell.textLabel?.text = foods[indexPath.row]

        return cell
    }

    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Check if the segue is the right one
        if segue.identifier == "showFoodDetail" {
            // Get the new view controller using segue.destination.
            // Pass the selected object to the new view controller.
            if let indexPath = tableView.indexPathForSelectedRow {
                let food = foods[indexPath.row]
                // Correct capitalization and casting for the destination view controller
                if let foodDetailViewController = segue.destination as? FoodDetailViewController {
                    foodDetailViewController.foodName = food
                }
            }
        }
    }
}
